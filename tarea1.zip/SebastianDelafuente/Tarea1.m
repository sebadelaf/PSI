%% 
clearvars;
close all;
clc;

% Función Winograd: calcula 2 salidas dados los parámetros solicitados
function [y1, y2] = winograd(x0, x1, x2, x3, h0, h1, h2)
    t1 = (h0 + h1 + h2) / 2;
    t2 = (h0 - h1 + h2) / 2;
    
    m1 = (x0 - x2) * h0;
    m2 = (x1 + x2) * t1;
    m3 = (x2 - x1) * t2;
    m4 = (x1 - x3) * h2;
    
    y1 = m1 + m2 + m3;
    y2 = m2 - m3 - m4;
end

% Función convolucion: Realiza la convolución usando el método de Winograd
% F(2,3) de manera extendida
function y = convol(x, h)
    L_h = length(h);
    if mod(L_h, 3) ~= 0
        error('Error: La longitud del filtro debe ser múltiplo de 3.');
    end
    % Longitud de la señal de entrada x y tamaño de la salida Y[n]
    L_x = length(x);
    L_y = L_h + L_x - 1;
    x_col = x(:); %establecer formato columna 
    x_pad = [x_col; zeros(L_h - 1, 1)]; %agregar el zero padding

    % Inicializar el vector de salida Y[n]
    y = zeros(L_y, 1);
    
    K = L_h / 3; %cantidad de segmentos del filtro a recorrer
    
    % Procesar cada segmento de h
    for k = 0:(K - 1)
        h_seg = h((k * 3) + 1:(k * 3) + 3); %arreglo de la tripleta del filtro para el segmento k
        h1 = h_seg(1); h2 = h_seg(2); h3 = h_seg(3);
        offset = k * 5;
        % Iterar sobre las muestras de salida. calcular el par de salidas
        for i = 0:(L_y / 2) - 1 
            n = i * 2 + 1;  
            idx_x = n:(n + 3);  
            vals = zeros(4, 1);  
            
            valid_idx = idx_x(idx_x <= length(x_pad)); 
            vals(1:length(valid_idx)) = x_pad(valid_idx);
            
            x1 = vals(1); 
            x2 = vals(2); 
            x3 = vals(3);
            x4 = vals(4);

            % Realizar la convolución con Winograd
            [y1_step, y2_step] = winograd(x1, x2, x3, x4, h1, h2, h3);
            
            % Calcular los índices en la salida yconv
            idx_y1 = i * 2 + 1 + offset;
            idx_y2 = i * 2 + 2 + offset;
            
            % Asignar los valores a la salida si están dentro de los límites
            if idx_y1 <= L_y
                y(idx_y1) = y(idx_y1) + y1_step;
            end
            if idx_y2 <= L_y
                y(idx_y2) = y(idx_y2) + y2_step;
            end
        end
    end
end

% Función conv_toeplitz: Realiza la convolución usando la matriz Toeplitz
function y = conv_toeplitz(x, h)
    x_col = x(:);
    h_col = h(:);

    L_x = length(x_col);
    L_h = length(h_col);

    H = convmtx(h_col, L_x);

    y = H * x_col;
end

% Prueba con señales y filtros
Lx = 8;  
Lh = 6;  
x = -1 + 2 * rand(Lx, 1);  
h = -1 + 2 * rand(Lh, 1);  

% Realizar la convolución usando Winograd, Toeplitz y la función de MATLAB
y_w = convol(x, h);
y_t = conv_toeplitz(x, h);
y_m = conv(x, h);

% Comparar los resultados con la norma de la diferencia
diff_t = norm(y_t - y_m);
diff_w = norm(y_w - y_m);

% Medir los tiempos de ejecución para diferentes tamaños de entrada
Lh_timing = 6;  
h_timing = -1 + 2 * rand(Lh_timing, 1); ;  
i_range = 3:13;  

num_tests = length(i_range);
times_w = zeros(num_tests, 1);  
times_t = zeros(num_tests, 1);  
times_m = zeros(num_tests, 1);  
Lx_vals = zeros(num_tests, 1);  

% Bucle para medir el tiempo de ejecución
for idx = 1:num_tests
    i = i_range(idx);
    Lx_curr = 2^i;  
    Lx_vals(idx) = Lx_curr;

    x_curr = -1 + 2 * rand(Lx_curr, 1);

    f_w = @() convol(x_curr, h_timing);
    times_w(idx) = timeit(f_w);

    f_t = @() conv_toeplitz(x_curr, h_timing);
    times_t(idx) = timeit(f_t);

    f_m = @() conv(x_curr, h_timing);
    times_m(idx) = timeit(f_m);
end

% Gráfico comparativo de tiempos de ejecución
figure;
loglog(Lx_vals, times_w, 'bo-', 'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', 'Winograd F(2,3)');
hold on;
loglog(Lx_vals, times_t, 'rx-', 'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', 'Matriz Toeplitz');
loglog(Lx_vals, times_m, 'gd-', 'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', 'MATLAB conv()');
hold off;

% Añadir títulos, etiquetas y leyenda al gráfico
title('Tiempo de Ejecución vs Longitud de Señal');
xlabel('Longitud Señal x (L_x)');
ylabel('Tiempo de Ejecución (s)');
legend('show', 'Location', 'NorthWest');
grid on;
set(gca, 'XTick', 2.^i_range);  
set(gca, 'XTickLabelRotation', 45);  
