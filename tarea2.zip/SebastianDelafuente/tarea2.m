%limpieza de variables e imagenes
clearvars
close all
clc
% Paso 1: Obtener los datos de CO2
try
    data = readmatrix('co2_daily_spo.txt');
catch
    error('No se pudo leer el archivo co2_daily_spo.txt. Asegúrate de que esté en el directorio correcto.');
end

% Paso 2: Obtener la señal de datos inicial (x1[n]) y calcular N1 (años 2016-2017)
year1_start = 2016;
year1_end = 2017;
% Filtrar datos para los años 2016 y 2017
data_x1 = data(data(:,1) >= year1_start & data(:,1) <= year1_end, :);

% Extraer los valores de CO2
x1 = data_x1(:, 4);
N1 = length(x1); 

% Crear vector de índice de tiempo para x1 (comenzando en 0 como en el enunciado)
t1 = 0:N1-1;

% Crear vector de fechas para plotting más preciso de x1
dates_x1 = datetime(data_x1(:,1), data_x1(:,2), data_x1(:,3));

% Paso 3: Calcular la predicción de tendencia lineal (l1[n]) y los residuos (xr[n])
[a, ~, mu] = polyfit(t1', x1, 1); 

% polyval(p, x) evalúa el polinomio p en los puntos x
l1 = polyval(a, t1, [], mu);

% Calcular los residuos: datos observados - tendencia lineal
xr = x1 - l1';

% Paso 4: Generar gráfico de datos observados y tendencia lineal
figure;
plot(dates_x1, x1, 'b-', 'DisplayName', 'x1[n] Observado');
hold on; % Mantener el gráfico actual para añadir más elementos
plot(dates_x1, l1, 'r-', 'DisplayName', 'l1[n] Tendencia Lineal');
xlabel('Fecha');
ylabel('CO2 (ppm)');
title(sprintf('Datos Observados y Tendencia Lineal (%d-%d)', year1_start, year1_end));
legend;
grid on;
hold off; % Liberar el gráfico

% Paso 5: Generar gráfico de los residuos
figure;
plot(dates_x1, xr, 'b-', 'DisplayName', 'xr[n] Residuos');
xlabel('Fecha');
ylabel('Residuos (ppm)');
title(sprintf('Residuos de la Predicción Lineal (%d-%d)', year1_start, year1_end));
legend;
grid on

% Paso 6: Obtener la serie temporal extendida (x2[n]) y calcular N2 (años 2016-2024)
year2_start = 2016;
year2_end = 2024;

% Filtrar datos para los años 2016 a 2024
data_x2 = data(data(:,1) >= year2_start & data(:,1) <= year2_end, :);

% Extraer los valores de CO2
x2 = data_x2(:, 4);
N2 = length(x2);

% Crear vector de índice de tiempo para x2
t2 = 0:N2-1;

% Crear vector de fechas para plotting más preciso de x2
dates_x2 = datetime(data_x2(:,1), data_x2(:,2), data_x2(:,3));

% Paso 7: Calcular la predicción de tendencia lineal extendida (l2[n])
l2 = polyval(a, t2, [], mu);

% Paso 8: Calcular la transformada de Fourier de los residuos (Xr[k]) y su aproximación (xr[n])
Xr = fft(xr); 

% Seleccionar una cantidad de armónicos nh para la aproximación
nh = 3;

% Calcular las magnitudes de los coeficientes
magnitudes = abs(Xr(2:floor(N1/2)+1));

% Ordenar las magnitudes de forma descendente y obtener los índices
[~, sorted_indices] = sort(magnitudes, 'descend');

% Obtener los índices (1-based, relativos al inicio de magnitudes) de los nh armónicos más grandes
selected_pos_k_relative = sorted_indices(1:nh);

% Convertir estos índices relativos a los índices k de la FFT
selected_pos_k_fft_indices = selected_pos_k_relative + 1;

% Asegurarse de que selected_pos_k_fft_indices sea un vector fila
selected_pos_k_fft_indices = selected_pos_k_fft_indices(:)'; % Convertir a fila

selected_k_indices = [1, selected_pos_k_fft_indices];

% Incluir negativos frequency counterparts
selected_neg_k_fft_indices = N1 - (selected_pos_k_fft_indices - 1) + 1;

% Combinar todos los índices seleccionados y eliminar duplicados
all_selected_indices = unique([selected_k_indices, selected_neg_k_fft_indices]);

% Construir la aproximación xr[n] para el rango extendido (0 a N2-1)
% Usamos la fórmula de la serie de Fourier con los coeficientes seleccionados
xr = zeros(N2, 1); 
omega0 = 2 * pi / N1;

for n = 0:N2-1 % Iterar sobre el rango de tiempo extendido
    sum_val = 0;
    for k_idx = all_selected_indices
        k = k_idx - 1;
        sum_val = sum_val + Xr(k_idx) * exp(1j * k * omega0 * n);
    end
    % APLICAR EL FACTOR DE ESCALA 1/N1 para que el grafico se muestre
    % correctamente a escala de los datos originales
    xr(n+1) = sum_val / N1;
end

% Asegurarse de que xr sea real, ya que la señal original era real
xr = real(xr);


% Paso 9: Generar gráfico con datos extendidos, tendencia lineal extendida y predicción Fourier fitting
xp = xr + l2'; % Predicción Fourier

figure;
hold on;

% Asegurarse que las tres señales estén alineadas en el mismo gráfico
plot(dates_x2, x2, 'b-', 'DisplayName', 'x2[n] Observado (2016-2024)'); 
plot(dates_x2, l2, 'r-', 'DisplayName', 'l2[n] Tendencia Lineal');
plot(dates_x2, xp, 'k-', 'DisplayName', sprintf('xp[n] Predicción Fourier (nh=%d)', nh)); 

% Agregar etiquetas y título
xlabel('Fecha');
ylabel('CO2 (ppm)');
title('Comparación de Predicción Fourier y Datos Observados de CO2 Atmosférico');
legend;
grid on;

% Asegurarse que la escala y los límites del gráfico sean adecuados
axis tight; % Ajusta automáticamente los límites de los ejes para que se muestren todas las señales


% Paso 10: Calcular el MAPE
% Calcular el Error Promedio Absoluto Porcentual (MAPE)
% Evitar divisiones por cero si hay valores de x2 cercanos a cero
x2_cleaned = x2;
% Reemplazar valores cercanos a cero o cero con NaN para que no afecten la media
x2_cleaned(abs(x2_cleaned) < 1e-9) = NaN;

% Calcular el error porcentual absoluto
absolute_percentage_error = abs((x2 - xp) ./ x2_cleaned);

% Calcular la media de los errores porcentuales absolutos, ignorando NaNs
mape = nanmean(absolute_percentage_error) * 100;

fprintf('El Error Promedio Absoluto Porcentual es: %.2f%%\n', mape);